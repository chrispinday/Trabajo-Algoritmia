#ifndef DISTANCIA_H
#define DISTANCIA_H

#include "listaDinamicaDeDias.h"
#include <math.h>

//calcula la distancia entre dos días
float calcularDistancia(tipoDia dia1, tipoDia dia2);

#endif
