gcc -o k1 k1.c listaDinamicaDeDias.c fragmenta.c normalizacion.c distancia.c -lm
./k1
