#ifndef FRAGMENTA_H
#define FRAGMENTA_H

#include <stdbool.h>
#include <string.h>
#include "listaDinamicaDeDias.h"

tipoDia fragmenta(const char*);

#endif
