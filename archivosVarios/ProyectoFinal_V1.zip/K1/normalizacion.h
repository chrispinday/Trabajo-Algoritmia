#ifndef NORMALIZACION_H
#define NORMALIZACION_H

#include "listaDinamicaDeDias.h"

void normalizarDataset(tipoListaDinamicaDeDias *);
void normalizarCelda(tipoListaDinamicaDeDias *, celdaListaDeDias *);

#endif
